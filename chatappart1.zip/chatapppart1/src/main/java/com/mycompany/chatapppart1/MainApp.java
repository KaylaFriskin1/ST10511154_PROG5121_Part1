/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class   MainApp {
    public static void main(String[] args) {
        
        //Scanner allows user to enter information
        Scanner input = new Scanner(System.in);
        
        //create a object in the Login class so that we can call its methods
        Login login = new Login();
        
        //---Registration Section---
        System.out.println("=== User Registration ===");
        
        System.out.print("Enter a username: ");
        String username = input.nextLine();
        
        System.out.print("Enter a password: ");
        String password = input.nextLine();
        
        System.out.print("Enter your South African number (+27...): ");
        String phone = input.nextLine();
        
        //Call the registerUser method and store the message it returns
        String response = login.registerUser(username,password,phone);
        
        //Show the registration message
        System.out.println(response);
        
        //--Login Section---
        System.out.println("\n--- User Login ---");
        
        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine();
        
        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine();
        
        //Call loginUser to check if details match the stored ones
        boolean loggedIn = login.loginUser(loginUsername,loginPassword);
        
        //Print out the correct login message
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
    }
    
}
