/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

/**
 *
 * @author Student
 */
public class Login {
    
    //User's detailS will be stored under these variables
    //When registerd,their data will be saved.
    String username;
    String password;
    String cellPhoneNumber;

    //Checking username
    //The username obtains a underscore
    //The username has no more than 5 characters long
    
    public boolean checkUserName (String username) {
    //username.contains("_") checks for the underscore
    //username.length() <=5 ensures short username 
    return username.contains("_") && username.length() <= 5;
    }
    
    //Checking the password complexity
    public boolean checkPasswordComplexity(String password){
    boolean hasCapital = false;
    boolean hasNumber = false;
    boolean hasSpecial = false;
    
    // Loop through each characther in the password
    for (int i = 0; i < password.length(); i++) {
    char c = password.charAt(i); 
    //get the current
    if (Character.isUpperCase(c)) {
     hasCapital = true; 
     //found a Capital letter
    }
    else if (Character.isDigit(c)) {
    hasNumber = true; //found a number
    }
    else if (!Character.isLetterOrDigit(c)){
        hasSpecial = true;
        // found a special character
    }
    }
    //All conditions must be true to return true.
    return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
    }
    public boolean checkCellPhoneNumber(String phone){
            return phone.startsWith("+27") && phone.length() == 12;
    }
    public String registerUser(String username,String password,String phoneNumber){
        
    if (!checkUserName(username)){
        return "Username is not correctly formatted;please ensure that your username contains an underscore and is no more then five characters in length";
    }
    if (!checkPasswordComplexity(password)){
        return "Password is not correctly formatted,please ensure that the password contains at least eight characters,capital letter,a number,and a special character";
    }
    if (!checkCellPhoneNumber(phoneNumber)) {
        return "Cell phone number incorrectly formatted or does not contain international code";
    }
    
    this.username = username;
    this.password = password;
    this.cellPhoneNumber = cellPhoneNumber;
    
    return "User registerd successfully";
    }
      public boolean loginUser(String username,String password) {
          return this.username.equals(username) && this.password.equals(password);
    }
      public String returnLoginStatus(boolean success) {
          if (success) {
         return "Welcome " + this.username + " it is great to see you again";
          } else {
              return "Username or password incorrect,please try again";
          }
      

     // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
         
    
    
    

