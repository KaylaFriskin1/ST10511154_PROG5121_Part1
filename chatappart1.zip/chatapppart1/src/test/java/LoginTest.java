/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class LoginTest {
    
  Login login = new Login ();
 
  @Test
  public void testValidUsername(){
      //this checks the username must have the underscore "_"
      //also checks the length of the username must not be more than 5 (e.g "Kayla")
      assertTrue(login.checkUserName("Kyl_1"));
  }
   
@Test
public void testInvalidUsername_NoUnderscore () {
    //checks the username with no underscore
    
    assertFalse(login.checkUserName("Ky1"));
}

@Test
public void testInvalidUsername_TooLong(){
    //REASON WHY IT IS FALSE,THE USERNAME HAS MORE THAN 5 CHARACTERS
    //it was suppose to be 5
    assertFalse(login.checkUserName("Kyle1_"));
}
    
@Test

public void testValidPassword(){
    //Checking if password is accurate
    assertTrue(login.checkPassword ("User123@"));
}

@Test

public void testInValidPassword_NoCapital(){
    //Checks the password with no capital
    assertFalse(login.checkPassword ("user12@"));
}

@Test

public void testInValidPassword_NoNumber (){
    //Password will indicate invalid due to no entered number 
    assertFalse(login.checkPassword ("User@"));
}

@Test

public void testInValidPassword_NoSpecial () {
    //password will not be valid;there isnt a special case
    assertFalse(login.checkPassword("User12"));
    
}

   
     
    
 @Test

public void testValidCellPhoneNumber(){
    //The phone number must be exact ==13
    //and start with +27

    assertTrue(login.checkCellPhoneNumber ("+277838968976"));
}

@Test

public void testInValidCellPhoneNumber_NoFormatted(){
    //Cell phone number must include (+27) in the begining.
   assertFalse(login.checkCellPhoneNumber ("07838968976")); 
}

@Test

public void testInValidCellPhoneNumber_TooLong() {
   //Cell phone number needs to include ==12 exact if not,number wont be valid
   assertFalse(login.checkCellPhoneNumber("+2778389685854"));
}
}
